这是对[xv6-riscv-book](https://github.com/mit-pdos/xv6-riscv-book)的宽松翻译。现在(2020-02-17)：

- 没有翻译最后一章：重新审视并发。
- 各章最后的**真实世界**和**练习**没有翻译。
- 第一章后半部分没有翻译。

