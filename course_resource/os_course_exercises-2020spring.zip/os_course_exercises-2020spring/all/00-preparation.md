# 操作系统概述
---

## **提前准备**
（请在上课前完成）

 - 尝试访问在线实验平台
   1. 通过浏览器访问 ["实验楼"在线实验环境](http://www.shiyanlou.com/courses/221)
   2. 通过ssh工具 学号@腾讯云主机
 - 了解piazza的功能和使用方法
  - https://piazza.com/class/i5j09fnsl7k5x0
 - 熟练掌握git和github网站的使用，在github上建立自己的帐号。
 - 会熟练使用Linux开发环境，特别是命令行操作环境。熟悉一种C或RUST语言的IDE开发环境。
 - 通过看MOOC OS视频来提前预习OS课程。

